import { chromium, type Locator, type Page } from 'patchright'
import { z } from 'zod'

const resultSchema = z.object({
    sourceUrl: z.url(),
    externalId: z.string().min(1),
    name: z.string().min(1),
    rating: z.number().min(1).max(5),
    ratingCount: z.number().int().nonnegative(),
    reviewCount: z.number().int().nonnegative(),
    reviews: z.array(
        z.object({
            externalId: z.string().min(1).optional(),
            author: z.string().min(1),
            publishedAt: z.string().min(1),
            text: z.string().nullable(),
            rating: z.number().int().min(1).max(5)
        })
    )
})

export type ParseResult = z.infer<typeof resultSchema>

export type ParseProgress = {
    stage: 'opening_page' | 'reading_summary' | 'collecting_reviews'
    collected_reviews: number
    expected_reviews: number | null
}

export class ParserError extends Error {
    public constructor(
        public readonly code:
            | 'invalid_url'
            | 'source_unavailable'
            | 'access_limited'
            | 'markup_changed'
            | 'incomplete_result'
            | 'temporary_error',
        message: string,
        public readonly httpStatus: number
    ) {
        super(message)
    }
}

const selectors = {
    reviewTab: [
        'a[href*="reviews"]',
        'button:has-text("Отзывы")',
        '[role="tab"]:has-text("Отзывы")'
    ],
    reviewContainer: [
        '[data-testid="reviews-list"]',
        '[class*="business-reviews-card-view__reviews-container"]',
        '[class*="reviews-list"]'
    ],
    reviewCard: ['div.business-review-view'],
    organizationName: [
        'h1',
        '[itemprop="name"]',
        '[class*="business-card-title"]'
    ],
    rating: [
        '[itemprop="ratingValue"]',
        '[class*="business-summary-rating-badge-view"]',
        '[aria-label*="рейтинг"]'
    ],
    ratingCount: ['[itemprop="ratingCount"]', '[class*="rating-count"]'],
    reviewCount: ['[itemprop="reviewCount"]', '[class*="reviews-count"]'],
    reviewAuthor: ['.business-review-view__author-name'],
    reviewDate: ['.business-review-view__date'],
    reviewText: ['.business-review-view__body'],
    reviewRating: ['span[itemprop="reviewRating"] [itemprop="ratingValue"]']
}

type ApiReview = {
    reviewId?: string
    author?: {
        name?: string
    }
    text?: string | null
    rating?: number
    updatedTime?: string
    createdTime?: string
}

type FetchReviewsResponse = {
    data?: {
        reviews?: ApiReview[]
    }
    error?: {
        code?: number
        message?: string
    }
}

export class YandexMapsParser {
    public async parse(
        sourceUrl: string,
        reportProgress: (progress: ParseProgress) => Promise<void>
    ): Promise<ParseResult> {
        this.assertYandexMapsUrl(sourceUrl)

        const browser = await chromium.launch({
            headless: false
        })

        try {
            const context = await browser.newContext({
                locale: 'ru-RU',
                viewport: {
                    width: 1440,
                    height: 1100
                }
            })

            const page = await context.newPage()

            page.setDefaultTimeout(20_000)

            await reportProgress({
                stage: 'opening_page',
                collected_reviews: 0,
                expected_reviews: null
            })

            const pageResponse = await page.goto(sourceUrl, {
                waitUntil: 'domcontentloaded',
                timeout: 45_000
            })

            await page.waitForTimeout(1000)

            if (!pageResponse || pageResponse.status() >= 500) {
                throw new ParserError(
                    'source_unavailable',
                    'Yandex Maps is temporarily unavailable.',
                    503
                )
            }

            await this.assertPageIsAvailable(page)

            if (!page.url().includes('/reviews')) {
                await this.openReviews(page)
            }

            await reportProgress({
                stage: 'reading_summary',
                collected_reviews: 0,
                expected_reviews: null
            })

            const summary = await this.extractSummary(page)

            const reviews = await this.collectReviews(
                page,
                summary.reviewCount,
                reportProgress
            )

            if (summary.reviewCount > 0 && reviews.length === 0) {
                throw new ParserError(
                    'incomplete_result',
                    'The page reports reviews, but none were extracted.',
                    422
                )
            }

            return resultSchema.parse({
                sourceUrl,
                externalId: this.extractOrganizationId(page.url()),
                name: summary.name,
                rating: summary.rating,
                ratingCount: summary.ratingCount,
                reviewCount: summary.reviewCount,
                reviews
            })
        } catch (error) {
            if (error instanceof ParserError) {
                throw error
            }

            if (error instanceof z.ZodError) {
                throw new ParserError(
                    'markup_changed',
                    'The extracted data no longer matches the expected contract.',
                    422
                )
            }

            if (
                error instanceof Error &&
                (error.message.includes('net::ERR_') ||
                    error.name === 'TimeoutError')
            ) {
                throw new ParserError(
                    'source_unavailable',
                    'Yandex Maps could not be reached.',
                    503
                )
            }

            throw new ParserError(
                'temporary_error',
                'The parser could not complete the request.',
                503
            )
        } finally {
            await browser.close()
        }
    }

    private assertYandexMapsUrl(value: string): void {
        let url: URL

        try {
            url = new URL(value)
        } catch {
            throw new ParserError(
                'invalid_url',
                'Only valid Yandex Maps organization URLs are supported.',
                422
            )
        }

        const isYandexDomain =
            url.hostname === 'yandex.ru' ||
            url.hostname.endsWith('.yandex.ru') ||
            url.hostname === 'yandex.com' ||
            url.hostname.endsWith('.yandex.com')

        if (!isYandexDomain || !url.pathname.includes('/maps')) {
            throw new ParserError(
                'invalid_url',
                'Only Yandex Maps organization URLs are supported.',
                422
            )
        }
    }

    private async assertPageIsAvailable(page: Page): Promise<void> {
        const content = (await page.locator('body').innerText()).toLowerCase()

        if (
            content === 'limited' ||
            content.includes('captcha') ||
            content.includes('доступ ограничен') ||
            content.includes('слишком много запросов')
        ) {
            throw new ParserError(
                'access_limited',
                'Yandex Maps limited access to this request.',
                429
            )
        }
    }

    private async openReviews(page: Page): Promise<void> {
        for (const selector of selectors.reviewTab) {
            const tab = page.locator(selector).first()

            if (await tab.isVisible().catch(() => false)) {
                await tab.click()
                await page.waitForTimeout(700)

                return
            }
        }

        throw new ParserError(
            'markup_changed',
            'The reviews tab was not found.',
            422
        )
    }

    private async extractReviewCount(page: Page): Promise<number | null> {
        const locator = page.locator('meta[itemprop="reviewCount"]').first()

        const content = await locator.getAttribute('content')

        if (!content) {
            return null
        }

        const value = Number(content)

        return Number.isInteger(value) && value >= 0 ? value : null
    }

    private async extractSummary(page: Page): Promise<{
        name: string
        rating: number
        ratingCount: number
        reviewCount: number
    }> {
        const name = await this.firstText(page, selectors.organizationName)

        const ratingText = await this.firstText(page, selectors.rating)

        const ratingCountText = await this.firstText(
            page,
            selectors.ratingCount
        )

        const reviewCountText = await this.firstText(
            page,
            selectors.reviewCount
        )

        const rating = this.parseRating(ratingText)

        const ratingCount = this.parseCount(ratingCountText)

        const parsedReviewCount = this.parseCount(reviewCountText)

        const fallbackReviewCount = await this.extractReviewCount(page)

        const reviewCount = parsedReviewCount ?? fallbackReviewCount

        if (
            !name ||
            rating === null ||
            ratingCount === null ||
            reviewCount === null
        ) {
            throw new ParserError(
                'markup_changed',
                'Required organization summary fields were not found.',
                422
            )
        }

        return {
            name,
            rating,
            ratingCount,
            reviewCount
        }
    }

    private async collectReviews(
        page: Page,
        expectedReviewCount: number,
        reportProgress: (progress: ParseProgress) => Promise<void>
    ): Promise<ParseResult['reviews']> {
        const container = await this.firstVisibleLocator(
            page,
            selectors.reviewContainer
        )

        const reviews = new Map<string, ParseResult['reviews'][number]>()

        const renderedReviews = await this.extractRenderedReviews(container)

        for (const review of renderedReviews) {
            const key =
                review.externalId ??
                `${review.author}|${review.publishedAt}|${review.rating}|${review.text ?? ''}`

            reviews.set(key, review)
        }

        await reportProgress({
            stage: 'collecting_reviews',
            collected_reviews: reviews.size,
            expected_reviews: expectedReviewCount
        })

        const apiReviews = new Map<string, ParseResult['reviews'][number]>()

        const responseHandler = async (
            response: Awaited<ReturnType<Page['waitForResponse']>>
        ): Promise<void> => {
            const request = response.request()

            if (
                request.resourceType() !== 'fetch' &&
                request.resourceType() !== 'xhr'
            ) {
                return
            }

            if (!response.url().includes('/api/business/fetchReviews')) {
                return
            }

            const url = new URL(response.url())

            if (response.status() >= 400) {
                return
            }

            let body: FetchReviewsResponse

            try {
                body = await response.json()
            } catch {
                return
            }

            for (const review of body.data?.reviews ?? []) {
                const reviewId = review.reviewId

                const author = review.author?.name?.trim()

                const publishedAt = review.createdTime ?? review.updatedTime

                const rating = review.rating

                if (
                    !reviewId ||
                    !author ||
                    !publishedAt ||
                    !Number.isInteger(rating) ||
                    rating < 1 ||
                    rating > 5
                ) {
                    continue
                }

                apiReviews.set(reviewId, {
                    externalId: reviewId,
                    author,
                    publishedAt,
                    text: review.text ?? null,
                    rating
                })
            }
        }

        page.on('response', responseHandler)

        try {
            for (let pageNumber = 2; pageNumber <= 12; pageNumber++) {
                const currentContainer = await this.firstVisibleLocator(
                    page,
                    selectors.reviewContainer
                )

                const cards = currentContainer.locator(
                    selectors.reviewCard.join(', ')
                )

                const cardCount = await cards.count()

                if (cardCount === 0) {
                    break
                }

                await cards.nth(cardCount - 1).scrollIntoViewIfNeeded()

                await page.waitForTimeout(2500)

                await this.assertPageIsAvailable(page)

                await reportProgress({
                    stage: 'collecting_reviews',
                    collected_reviews: reviews.size + apiReviews.size,
                    expected_reviews: expectedReviewCount
                })
            }
        } finally {
            page.off('response', responseHandler)
        }

        for (const [reviewId, review] of apiReviews) {
            reviews.set(reviewId, review)
        }

        await reportProgress({
            stage: 'collecting_reviews',
            collected_reviews: reviews.size,
            expected_reviews: expectedReviewCount
        })

        return [...reviews.values()]
    }

    private async extractRenderedReviews(
        container: Locator
    ): Promise<ParseResult['reviews']> {
        const cards = container.locator(selectors.reviewCard.join(', '))

        const count = await cards.count()

        const reviews: ParseResult['reviews'] = []

        for (let index = 0; index < count; index++) {
            const card = cards.nth(index)

            const author = await this.firstText(card, selectors.reviewAuthor)

            const dateLocator = card
                .locator('meta[itemprop="datePublished"]')
                .first()

            const publishedAt = await dateLocator.getAttribute('content')

            const ratingLocator = card
                .locator(
                    'span[itemprop="reviewRating"] [itemprop="ratingValue"]'
                )
                .first()

            const ratingContent = await ratingLocator.getAttribute('content')

            const rating = ratingContent ? Number(ratingContent) : null

            const text = await this.firstText(card, selectors.reviewText)

            if (
                !author ||
                !publishedAt ||
                rating === null ||
                !Number.isInteger(rating) ||
                rating < 1 ||
                rating > 5
            ) {
                continue
            }

            const externalId =
                (await card.getAttribute('data-review-id')) ??
                (await card.getAttribute('id')) ??
                undefined

            reviews.push({
                externalId,
                author,
                publishedAt,
                text,
                rating
            })
        }

        return reviews
    }

    private async firstVisibleLocator(
        page: Page,
        candidates: string[]
    ): Promise<Locator> {
        for (const selector of candidates) {
            const locator = page.locator(selector).first()

            if (await locator.isVisible().catch(() => false)) {
                return locator
            }
        }

        throw new ParserError(
            'markup_changed',
            'The reviews container was not found.',
            422
        )
    }

    private async firstText(
        parent: Page | Locator,
        candidates: string[]
    ): Promise<string | null> {
        for (const selector of candidates) {
            const locator = parent.locator(selector).first()

            if (await locator.isVisible().catch(() => false)) {
                const text = (await locator.innerText())
                    .replace(/\s+/g, ' ')
                    .trim()

                if (text) {
                    return text
                }
            }
        }

        return null
    }

    private parseRating(value: string | null): number | null {
        if (!value) {
            return null
        }

        const match = value.replace(',', '.').match(/[1-5](?:\.\d+)?/)

        return match ? Number(match[0]) : null
    }

    private parseCount(value: string | null): number | null {
        if (!value) {
            return null
        }

        const digits = value.replace(/[^\d]/g, '')

        return digits ? Number(digits) : null
    }

    private extractOrganizationId(url: string): string {
        const match = url.match(/\/org\/[^/]+\/(\d+)/)

        if (!match) {
            throw new ParserError(
                'markup_changed',
                'Organization ID was not found in the final URL.',
                422
            )
        }

        return match[1]
    }
}
